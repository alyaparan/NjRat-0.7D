![img](./image.png)

# njRAT-0.8.0-LIME-EDITION
njRAT has been around since at least 2013 and is one of the most prevalent malware families. Built in .NET Framework, the malware provides attackers with remote control over the infected systems, utilizes dynamic DNS for command-and-control (C&amp;C), and uses a custom TCP protocol over a configurable port for communication. Dubbed njRAT Lime Edition, the new malware variant includes support for ransomware infection, Bitcoin grabber, and distributed denial of service (DDoS), while also being able to log keystrokes, spread via USB drives, steal passwords, and lock the screen.


# Current Features
* Socket Key Changer
* Malware Killer
* USB Spread
* Anti Vmware Sandboxie .. etc
* Show Anti-Virus Software
* Startup using *.URL
* Reconnect Timeout
* Sleep
* Persistence
* Bypass UAC
* Hide
* Torrent Seeder
* Message Box
* Visit webpage visible or hidden
* Task Manager Disable or Enable
* CMD enable or disable [Admin]
* Chrome cookies remover
* Mouse reverse or normal
* Clipboard copy or clear
* Taskbar show or hide
* Monitor OFF or ON
* Text To Speech
* Delete EventsViewer [Admin]
* Downloader
* Updated GeoIP.dat
* Updated Passwords Recovery
* NO-IP Updater
* Assembly And Icon Changer
* Flooder
* Obfuscation
* MPress
* Plugin Compiler
* Visible Client
* Clean My PC
* Shutdown Restart PC

